<div class="card flex-fill p-3">
    <div class="card-header">
        <h5 class="card-title mb-3">Documents</h5>
        <a class="btn btn-success received_documents" href="javascript:;" id="received_documents"><i class="fas fa-hand"></i> Receive </a>
        <hr>
    </div>
    <table class="table table-hover table-striped " id="datatable_with_select" style="width: 100%; ">
        <thead>
            <tr>
                <th></th>
                <th>#</th>
                <th>Tracking Number</th>
                <th>Document Name</th>
                <th>From</th>
                <th>Document Type</th>
                <th>Remarks</th>
                <th>Released Date - Time</th>
            </tr>
        </thead>
        <tfoot>
            <tr>
                <th></th>
                <th>#</th>
                <th>Tracking Number</th>
                <th>Document Name</th>
                <th>From</th>
                <th>Document Type</th>
                <th>Remarks</th>
                <th>Released Date - Time</th>
            </tr>
        </tfoot>
    </table>
</div>