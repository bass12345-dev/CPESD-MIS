@extends('systems.dts.admin.layout.admin_master')
@section('title', $title)
@section('content')
@include('global_includes.title')

@endsection
@section('js')
<script>

</script>
@endsection