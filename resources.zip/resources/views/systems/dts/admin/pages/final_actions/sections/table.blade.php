<div class="card flex-fill p-3">
   <div class="card-header">
      <h5 class="card-title mb-0">Final Actions</h5>
   </div>
   <table class="table table-hover  " id="datatables-buttons" style="width: 100%; ">
      <thead>
         <tr>
            <th>#</th>
            <th>Type</th>
            <th>Created</th>
            <th>Action</th>
         </tr>
      </thead>
   </table>
</div>