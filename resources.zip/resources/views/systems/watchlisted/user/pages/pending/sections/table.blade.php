<div class="card flex-fill p-3">
    <div class="card-header">
      
        <button class="btn btn-danger" id="delete">Delete</button>
        <hr>
    </div>
    <table class="table table-hover table-striped " id="datatable_with_select" style="width: 100%; ">
        <thead>
            <tr>
                <th></th>
                <th>#</th>
                <th>Name</th>
                <th>Age</th>
                <th>Address</th>
                <th>Email</th>
                <th>Phone Number</th>

            </tr>
        </thead>
        <tfoot>
            <tr>
                <th></th>
                <th>#</th>
                <th>Name</th>
                <th>Age</th>
                <th>Address</th>
                <th>Email</th>
                <th>Phone Number</th>

            </tr>
        </tfoot>
    </table>
</div>