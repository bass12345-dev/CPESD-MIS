<div class="card flex-fill p-3">
    <table class="table table-hover table-striped " id="datatables-buttons" style="width: 100%; ">
        <thead>
            <tr>
                <th></th>
                <th>Name</th>
                <th>Action</th>
                <th>Type</th>
                <th>Date And Time</th>

            </tr>
        </thead>
    </table>
</div>