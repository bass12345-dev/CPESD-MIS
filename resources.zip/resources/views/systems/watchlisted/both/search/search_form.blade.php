<div class="card">
    <div class="card-header">
        <h5 class="card-title mb-0"></h5>
    </div>
    <div class="card-body">
        <form id="search_form">
            <div class="form-row mb-2">


                <div class="form-group col-md-12 mb-3">
                    <label for="inputEmail4">First Name</label>
                    <input type="text" name="first_name" class="form-control">
                </div>
                <div class="form-group col-md-12 mb-3">
                    <label for="inputEmail4">Last Name</label>
                    <input type="text" name="last_name" class="form-control">
                </div>

            </div>
            <button type="submit" class="btn btn-primary">Search</button>
        </form>
    </div>
</div>