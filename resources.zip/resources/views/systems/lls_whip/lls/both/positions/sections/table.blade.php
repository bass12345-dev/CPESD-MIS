    <!-- Data Table area Start-->

    <div class="data-table-list">
        <div class="basic-tb-hd">
            <h2>Position List</h2>
            <button class="btn btn-danger multi-delete" id="multi-delete" >Delete</button>
        </div>
        <div class="table-responsive">
            <table id="data-table-basic" class="table table-striped">
                <thead>
                    <tr>
                        <th></th>
                        <th>Position</th>
                        <th>Created</th>
                        <th>Action</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>