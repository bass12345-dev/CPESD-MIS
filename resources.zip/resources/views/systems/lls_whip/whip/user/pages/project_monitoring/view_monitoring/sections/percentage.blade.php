<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
    <div class="card flex-fill p-3">
        <table class="table table-hover table-striped table-information " style="width: 100%; ">
            <tr style="border : 1px solid #000">
                <td style="border : 1px solid #000" >Percentage Rate of Hired Skilled Workers</td>
                <td style="border : 1px solid #000"  class="text-start text-bold"><span class="title total_skilled"></span></td>
            </tr>
            <tr>
                <td style="border : 1px solid #000;" >Percentage Rate of Hired UnSkilled Workers</td>
                <td style="border : 1px solid #000" class="text-start text-bold"><span class="title total_unskilled "></span></td>
            </tr>
        </table>
    </div>
</div>
