@extends('systems.lls_whip.whip.user.layout.user_master')
@section('title', $title)
@section('content')
@include('systems.lls_whip.whip.user.pages.dashboard.sections.count1')
@endsection
@section('js')
@endsection