<!-- Data Table area Start-->
<div class="data-table-area">
    <div class="container">
        <div class="data-table-list">
        <h1>Project/s</h1>
            <div class="table-responsive">
                <table id="data-table-basic" class="table table-striped">
                    <thead>
                        <tr>
                           
                            <th>#</th>
                            <th>Project Title</th>
                            <th>Project Cost</th>
                            <th>Project Location</th>
                            <th>Project Nature</th>
                            <th>Date Started</th>
                            <th>Date Completed</th>
                            <th>Status</th>

                        </tr>
                    </thead>

                </table>
            </div>
        </div>

    </div>
</div>

<!-- Data Table area End-->