@extends('systems.lls_whip.whip.admin.layout.admin_master')
@section('title', $title)
@section('content')
@endsection
@section('js')
@endsection