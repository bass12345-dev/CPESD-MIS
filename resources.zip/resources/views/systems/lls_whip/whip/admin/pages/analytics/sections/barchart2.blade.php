<!--  -->

<!-- Data Table area Start-->
<div class="data-table-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="statistic-right-area notika-shadow mg-tb-5 sm-res-mg-t-0">
                    <div class="data-table-area">
                        <div class="container">
                            <div class="card-header d-flex">
                                @include('components.dts.select_year')
                                
                            </div>
                            <canvas id="monitoring-chart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Data Table area End-->