<div class="statistic-right-area notika-shadow mg-tb-5 sm-res-mg-t-0">
    <div class="row">
        <h4 class="text-center">Contractors</h4>
    </div>
    @include('components.lls.hamster_loader')
    <canvas  id="contractor-chart"></canvas>
</div>