<div class="row header_title_container" >
        <h1>{{$title}}</h1>
    </div>