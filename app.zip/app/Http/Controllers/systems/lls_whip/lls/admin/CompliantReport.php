<?php

namespace App\Http\Controllers\systems\lls_whip\lls\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class CompliantReport extends Controller
{
    //
}
